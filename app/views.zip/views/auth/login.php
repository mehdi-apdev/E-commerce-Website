<?php
// app/views/auth/login.php
$errors = $_SESSION['errors'] ?? [];
unset($_SESSION['errors']);
require APP_ROOT . '/views/partials/header.php';
?>

<div class="flex justify-center items-center min-h-screen pt-10 pb-16 px-4">
    <div class="w-full max-w-md">
        <div class="bg-white dark:bg-zinc-900 shadow-xl ring-1 ring-zinc-200 dark:ring-zinc-800 rounded-xl overflow-hidden">
            <div class="bg-primary text-white px-6 py-4">
                <h3 class="text-xl font-semibold">Connexion</h3>
            </div>

            <div class="px-6 py-5">
                <?php if (!empty($errors)): ?>
                    <div class="bg-red-100 text-red-800 p-3 rounded mb-4 text-sm">
                        <ul class="list-disc list-inside">
                            <?php foreach ($errors as $error): ?>
                                <li><?= $error ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form id="loginForm" method="POST" action="<?= url('auth/loginPost') ?>" class="space-y-5">
                    <div>
                        <label for="email" class="block mb-1 text-sm">Email</label>
                        <input type="email" id="email" name="email" required
                            class="input dark:bg-zinc-800 dark:text-white" />
                        <p id="email-error" class="text-red-500 text-sm mt-1"></p>
                    </div>

                    <div>
                        <label for="password" class="block mb-1 text-sm">Mot de passe</label>
                        <input type="password" id="password" name="password" required
                            class="input dark:bg-zinc-800 dark:text-white" />
                        <p id="password-error" class="text-red-500 text-sm mt-1"></p>
                    </div>

                    <div class="flex items-center gap-2">
                        <input type="checkbox" id="remember" name="remember"
                            class="rounded border-gray-300 dark:border-zinc-600 text-primary focus:ring-primary">
                        <label for="remember" class="text-sm">Se souvenir de moi</label>
                    </div>

                    <div>
                        <button type="submit" class="btn btn-primary w-full">Connexion</button>
                    </div>
                </form>
            </div>

            <div class="bg-gray-50 dark:bg-zinc-800 px-6 py-4 text-center text-sm">
                Vous n'avez pas de compte ? <a href="<?= url('auth/register') ?>" class="text-primary hover:underline">Inscrivez-vous</a>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('loginForm');

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        document.querySelectorAll('.input').forEach(el => el.classList.remove('border-red-500'));
        document.querySelectorAll('.text-red-500').forEach(el => el.textContent = '');

        fetch(this.action, {
            method: 'POST',
            body: new FormData(this)
        }).then(res => res.json()).then(response => {
            if (response.success) {
                window.location.href = response.redirect;
            } else {
                Object.entries(response.errors).forEach(([field, message]) => {
                    const input = document.getElementById(field);
                    const error = document.getElementById(`${field}-error`);
                    if (input) input.classList.add('border-red-500');
                    if (error) error.textContent = message;

                    if (field === 'auth') {
                        const errorBox = document.createElement('div');
                        errorBox.className = "bg-red-100 text-red-800 p-3 rounded mb-4 text-sm";
                        errorBox.innerText = message;
                        form.prepend(errorBox);
                    }
                });
            }
        }).catch(() => {
            const errorBox = document.createElement('div');
            errorBox.className = "bg-red-100 text-red-800 p-3 rounded mb-4 text-sm";
            errorBox.innerText = "Une erreur est survenue. Veuillez réessayer.";
            form.prepend(errorBox);
        });
    });
});
</script>

<?php require APP_ROOT . '/views/partials/footer.php'; ?>

<?php
// Get any stored errors and form data
$errors = $_SESSION['errors'] ?? [];
$formData = $_SESSION['form_data'] ?? [];

// Clear session data after retrieval
unset($_SESSION['errors'], $_SESSION['form_data']);

// Include header
require APP_ROOT . '/views/partials/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow">
            <div class="card-header bg-primary text-white">
                <h3 class="mb-0">Créer un compte</h3>
            </div>
            <div class="card-body">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0">
                            <?php foreach ($errors as $error): ?>
                                <li><?= $error ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <form id="registerForm" method="POST" action="<?= url('auth/registerPost') ?>">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="first_name" class="form-label">Prénom</label>
                            <input type="text" class="form-control" id="first_name" name="first_name" 
                                   value="<?= $formData['first_name'] ?? '' ?>" required>
                            <div class="invalid-feedback" id="first_name-error"></div>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <label for="last_name" class="form-label">Nom</label>
                            <input type="text" class="form-control" id="last_name" name="last_name" 
                                   value="<?= $formData['last_name'] ?? '' ?>" required>
                            <div class="invalid-feedback" id="last_name-error"></div>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" 
                               value="<?= $formData['email'] ?? '' ?>" required>
                        <div class="invalid-feedback" id="email-error"></div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="phone" class="form-label">Téléphone (optionnel)</label>
                        <input type="tel" class="form-control" id="phone" name="phone" 
                               value="<?= $formData['phone'] ?? '' ?>">
                        <div class="invalid-feedback" id="phone-error"></div>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password" class="form-label">Mot de passe</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <div class="invalid-feedback" id="password-error"></div>
                        <small class="form-text text-muted">Le mot de passe doit contenir au moins <?= $minPasswordLength ?> caractères</small>
                    </div>
                    
                    <div class="mb-3">
                        <label for="password_confirm" class="form-label">Confirmer le mot de passe</label>
                        <input type="password" class="form-control" id="password_confirm" name="password_confirm" required>
                        <div class="invalid-feedback" id="password_confirm-error"></div>
                    </div>
                    
                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">S'inscrire</button>
                    </div>
                </form>
            </div>
            <div class="card-footer text-center">
                <p class="mb-0">Vous avez déjà un compte ? <a href="<?= url('auth/login') ?>">Connectez-vous</a></p>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#registerForm').on('submit', function(e) {
        e.preventDefault();
        
        // Reset any error messages
        $('.is-invalid').removeClass('is-invalid');
        $('.invalid-feedback').text('');
        $('.alert').remove();
        
        $.ajax({
            url: $(this).attr('action'),
            type: 'POST',
            data: $(this).serialize(),
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    window.location.href = response.redirect;
                } else {
                    // Display errors
                    $.each(response.errors, function(field, message) {
                        $('#' + field).addClass('is-invalid');
                        $('#' + field + '-error').text(message);
                        
                        // Special case for general errors
                        if (field === 'general') {
                            $('#registerForm').prepend(
                                '<div class="alert alert-danger mb-3">' + 
                                message + 
                                '</div>'
                            );
                        }
                    });
                }
            },
            error: function() {
                $('#registerForm').prepend(
                    '<div class="alert alert-danger mb-3">' + 
                    'Une erreur est survenue. Veuillez réessayer.' + 
                    '</div>'
                );
            }
        });
    });
});
</script>

<?php
// Include footer
require APP_ROOT . '/views/partials/footer.php';
?>
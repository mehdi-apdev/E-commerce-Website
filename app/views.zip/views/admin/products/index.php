<?php
// app/views/admin/products/index.php

$pageTitle = 'Gestion des produits - Admin';
require APP_ROOT . '/views/partials/header.php';
?>

<div class="container my-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3">Produits</h1>
        <a href="<?= url('admin/products/create') ?>" class="btn btn-success">
            <i class="bi bi-plus-circle"></i> Nouveau produit
        </a>
    </div>

    <?php if (!empty($products)): ?>
        <table class="table table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Nom</th>
                    <th>Catégorie</th>
                    <th>Prix</th>
                    <th>Image principal</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($products as $product): ?>
                <tr>
                    <td><?= $product['product_id'] ?></td>
                    <td><?= htmlspecialchars($product['name']) ?></td>
                    <td><?= htmlspecialchars($product['category_name'] ?? 'Inconnue') ?></td>
                    <td><?= formatPrice($product['price']) ?></td>
                    <td>
                        <?php if (!empty($product['main_image'])): ?>
                            <img src="<?= url('uploads/products/' . $product['product_id'] . '/' . $product['main_image']) ?>" alt="Image du produit" width="60">
                        <?php else: ?>
                            <span class="text-muted">Aucune image</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?= url('admin/products/edit/' . $product['product_id']) ?>" class="btn btn-sm btn-warning">
                            <i class="bi bi-pencil-square"></i>
                        </a>
                        <form action="<?= url('admin/products/delete/' . $product['product_id']) ?>" method="POST" class="d-inline" onsubmit="return confirm('Supprimer ce produit ?');">
                            <button type="submit" class="btn btn-sm btn-danger">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-muted">Aucun produit trouvé.</p>
    <?php endif; ?>
</div>

<?php require APP_ROOT . '/views/partials/footer.php'; ?>

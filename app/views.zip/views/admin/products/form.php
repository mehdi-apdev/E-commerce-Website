<?php
// app/views/admin/products/form.php

require APP_ROOT . '/views/partials/header.php';
?>

<div class="container">
    <h1><?= $pageTitle ?? 'Formulaire produit' ?></h1>

    <form action="<?= $isEdit ? url('admin/products/update/' . $product['product_id']) : url('admin/products/store') ?>" 
    method="POST" 
    enctype="multipart/form-data">

        <!-- Product Form - Basic Information Section -->
        <!-- Product Name Field -->
        <div class="mb-3">
            <label for="name" class="form-label">Nom du produit</label>
            <input type="text" name="name" id="name" class="form-control" required value="<?= htmlspecialchars($product['name'] ?? '') ?>">
        </div>

        <!-- Short Description Field - Brief overview of the product -->
        <div class="mb-3">
            <label for="short_description" class="form-label">Description courte</label>
            <input type="text" name="short_description" id="short_description" class="form-control" value="<?= htmlspecialchars($product['short_description'] ?? '') ?>">
        </div>

        <!-- Detailed Description Field - Complete product information -->
        <div class="mb-3">
            <label for="description" class="form-label">Description détaillée</label>
            <textarea name="description" id="description" class="form-control"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
        </div>

        <!-- Price Field - With decimal precision -->
        <div class="mb-3">
            <label for="price" class="form-label">Prix (€)</label>
            <input type="number" name="price" id="price" class="form-control" step="0.01" required value="<?= htmlspecialchars($product['price'] ?? '') ?>">
        </div>

        <!-- Product Classification Section -->
        <!-- Category Selection - Product's primary category -->
        <div class="mb-3">
            <label for="category_id" class="form-label">Catégorie</label>
            <select name="category_id" id="category_id" class="form-control" required>
                <option value="">-- Choisir une catégorie --</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat['category_id'] ?>"
                        <?= isset($product['category_id']) && $product['category_id'] == $cat['category_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($cat['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Color Selection - Product's color attribute -->
        <div class="mb-3">
            <label for="color_id" class="form-label">Couleur</label>
            <select name="color_id" id="color_id" class="form-select">
                <option value="">-- Sélectionner --</option>
                <?php foreach ($colors as $color): ?>
                    <option value="<?= $color['color_id'] ?>" 
                        <?= isset($product) && $product['color_id'] == $color['color_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($color['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Fabric Selection - Material the product is made of -->
        <div class="mb-3">
            <label for="fabric_id" class="form-label">Tissu</label>
            <select name="fabric_id" id="fabric_id" class="form-select">
                <option value="">-- Sélectionner --</option>
                <?php foreach ($fabrics as $fabric): ?>
                    <option value="<?= $fabric['fabric_id'] ?>" <?= ($product['fabric_id'] ?? '') == $fabric['fabric_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($fabric['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Cultural Region Selection - Product's cultural origin -->
        <div class="mb-3">
            <label for="cultural_region_id" class="form-label">Région culturelle</label>
            <select name="cultural_region_id" id="cultural_region_id" class="form-select">
                <option value="">-- Sélectionner --</option>
                <?php foreach ($regions as $region): ?>
                    <option value="<?= $region['region_id'] ?>" 
                        <?= isset($product) && $product['cultural_region_id'] == $region['region_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($region['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Product Source Section -->
        <!-- Supplier Selection - Who supplies/produces the product -->
        <div class="mb-3">
            <label for="supplier_id" class="form-label">Fournisseur</label>
            <select name="supplier_id" id="supplier_id" class="form-select">
                <option value="">-- Sélectionner --</option>
                <?php foreach ($suppliers as $supplier): ?>
                    <option value="<?= $supplier['supplier_id'] ?>" 
                        <?= isset($product) && $product['supplier_id'] == $supplier['supplier_id'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($supplier['name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Product Attributes Section -->
        <!-- Handmade Flag - Indicates if product is handcrafted -->
        <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" value="1" id="is_handmade" name="is_handmade"
                <?= isset($product) && $product['is_handmade'] ? 'checked' : '' ?>>
            <label class="form-check-label" for="is_handmade">
                Fabriqué à la main
            </label>
        </div>

        <!-- Product Image Section -->
        <!-- Main Image Upload - Primary product image -->
        <div class="mb-3">
            <label for="main_image" class="form-label">Image principale</label>
            <input type="file" name="main_image" id="main_image" class="form-control" accept="image/*">
        </div>

        <!-- Display Current Image (if in edit mode) -->
        <?php if ($isEdit && is_array($product)): ?>
            <div class="mb-3">
                <p>Image actuelle :</p>
                <?php if (!empty($product['main_image'])): ?>
                <img 
                    src="<?= url('uploads/products/' . $product['product_id'] . '/' . $product['main_image']) ?>"
                    alt="Image principale de <?= htmlspecialchars($product['name']) ?>"
                    class="img-thumbnail"
                    style="max-height: 200px;">
            </div>
            <?php else: ?>
                <div class="text-muted fst-italic">Aucune image principale n’a été ajoutée pour ce produit.</div>
            <?php endif; ?>
        <?php endif; ?>

        <div class="d-flex gap-2">
            <button type="submit" class="btn btn-success">Mettre à jour</button>
            <a href="<?= url('admin/products') ?>" class="btn btn-secondary">Retour</a>
        </div>

    </form>
</div>

<?php require APP_ROOT . '/views/partials/footer.php'; ?>

<?php
$pageTitle = 'Accueil - ' . SITE_NAME;
require APP_ROOT . '/views/partials/header.php';
?>

<!-- HERO SECTION -->
<section class="py-24 px-4 text-center">
  <div class="max-w-3xl mx-auto relative z-10">
    <h1 class="text-5xl font-heading text-primary mb-6 uppercase tracking-wider"><?= SITE_NAME ?></h1>
    <p class="text-xl text-gray-700 dark:text-gray-300 font-body mb-8">
      L'élégance du patrimoine algérien d'antan, à portée de main.
    </p>
    <a href="<?= url('products') ?>" class="btn btn-primary text-lg">Voir la collection</a>
  </div>
</section>




<!-- NOUVEAUTÉS -->
<section class="bg-light dark:bg-zinc-900 py-16">
  <div class="container mx-auto px-4">
    <h2 class="text-3xl font-bold text-center text-gray-800 dark:text-white mb-12">Nouveautés</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
      <?php if (!empty($latestProducts)): ?>
        <?php foreach ($latestProducts as $product): ?>
          <div class="bg-white dark:bg-zinc-800 rounded-xl shadow-md hover:shadow-2xl transition duration-300 overflow-hidden group">
            <div class="relative">
              <?php if (!empty($product['main_image'])): ?>
                <img src="<?= url('uploads/products/' . $product['product_id'] . '/' . $product['main_image']) ?>"
                     alt="<?= htmlspecialchars($product['name']) ?>"
                     class="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300">
              <?php else: ?>
                <div class="h-48 flex items-center justify-center bg-secondary dark:bg-primary text-white">
                  Aucune image
                </div>
              <?php endif; ?>
              <!-- Badge Nouveau -->
              <span class="absolute top-2 left-2 bg-primary text-white text-xs px-2 py-1 rounded">Nouveau</span>
            </div>
            <div class="p-4">
              <h3 class="text-lg font-semibold mb-1"><?= htmlspecialchars($product['name']) ?></h3>
              <p class="text-sm text-gray-600 dark:text-gray-300 mb-2"><?= htmlspecialchars($product['short_description']) ?></p>
              <p class="text-sm font-bold text-primary mb-3"><?= formatPrice($product['price']) ?></p>
              <a href="<?= url('products/view/' . $product['product_id']) ?>" class="text-sm underline text-primary">Voir</a>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p class="text-center text-gray-500 dark:text-gray-400">Aucun nouveau produit pour le moment.</p>
      <?php endif; ?>
    </div>
  </div>
</section>

<!-- MEILLEURES VENTES -->
<section class="bg-white dark:bg-zinc-900 py-16">
  <div class="container mx-auto px-4">
    <h2 class="text-3xl font-bold text-center text-gray-800 dark:text-white mb-12">Meilleures ventes</h2>
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
      <?php if (!empty($topSellingProducts)): ?>
        <?php foreach ($topSellingProducts as $product): ?>
          <div class="bg-white dark:bg-zinc-800 rounded-xl shadow-md hover:shadow-2xl transition duration-300 overflow-hidden group">
            <div class="relative">
              <?php if (!empty($product['main_image'])): ?>
                <img src="<?= url('uploads/products/' . $product['product_id'] . '/' . $product['main_image']) ?>"
                     alt="<?= htmlspecialchars($product['name']) ?>"
                     class="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300">
              <?php else: ?>
                <div class="h-48 flex items-center justify-center bg-secondary dark:bg-primary text-white">
                  Aucune image
                </div>
              <?php endif; ?>
              <!-- Badge Top Vente -->
              <span class="absolute top-2 left-2 bg-secondary dark:bg-primary text-xs px-2 py-1 rounded shadow text-primary dark:text-white">
                Top vente
              </span>
            </div>
            <div class="p-4">
              <h3 class="text-lg font-semibold mb-1"><?= htmlspecialchars($product['name']) ?></h3>
              <p class="text-sm text-gray-600 dark:text-gray-300 mb-2"><?= htmlspecialchars($product['short_description']) ?></p>
              <p class="text-sm font-bold text-primary mb-3"><?= formatPrice($product['price']) ?></p>
              <a href="<?= url('products/view/' . $product['product_id']) ?>" class="text-sm underline text-primary">Voir</a>
            </div>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <p class="text-center text-gray-500 dark:text-gray-400">Aucune vente enregistrée.</p>
      <?php endif; ?>
    </div>
  </div>
</section>

<?php require APP_ROOT . '/views/partials/footer.php'; ?>

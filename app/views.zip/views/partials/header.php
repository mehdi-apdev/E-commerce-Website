<!DOCTYPE html>
<!-- app/views/partials/header.php -->
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $pageTitle ?? SITE_NAME ?></title>

  <!-- Fonts -->
  <link rel="stylesheet" href="<?= url('assets/css/fonts.css') ?>">

  <!-- CSS compilé Tailwind -->
  <link rel="stylesheet" href="<?= url('assets/css/tailwind.css') ?>">
</head>
<body class="bg-light dark:bg-dark text-gray-800 dark:text-gray-100 font-body">

<header class="bg-white dark:bg-dark shadow-md sticky top-0 z-50">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
    <!-- Logo -->
    <a href="<?= url() ?>" class="text-2xl sm:text-3xl font-heading text-primary hover:opacity-80 transition">
      <?= SITE_NAME ?>
    </a>



    <!-- Mobile buttons (burger + theme) -->
    <div class="flex items-center gap-3 md:hidden">
    <!-- Burger -->
    <button id="menu-toggle" class="text-gray-600 dark:text-gray-200 focus:outline-none" aria-label="Menu">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M4 6h16M4 12h16M4 18h16"/>
        </svg>
    </button>

    <!-- Dark Mode Toggle -->
    <button id="toggle-dark" class="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-zinc-700 transition" title="Changer de thème">
        <svg id="sun-icon" class="h-5 w-5 hidden text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M12 3v1m0 16v1m8.66-8.66h-1M4.34 12H3m15.36 4.24l-.71-.71M6.34 6.34l-.71-.71m12.02 0l-.71.71M6.34 17.66l-.71.71M12 8a4 4 0 100 8 4 4 0 000-8z" />
        </svg>
        <svg id="moon-icon" class="h-5 w-5 hidden text-gray-800 dark:text-gray-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M21 12.79A9 9 0 1111.21 3a7 7 0 109.79 9.79z"/>
        </svg>
    </button>
    </div>



    <!-- Desktop nav -->
    <nav class="hidden md:flex items-center gap-6 text-sm sm:text-base font-body">
      <a href="<?= url() ?>" class="hover:text-primary transition">Accueil</a>
      <a href="<?= url('products') ?>" class="hover:text-primary transition">Produits</a>

      <?php if (isset($_SESSION['user'])): ?>
        <div class="relative group">
          <button class="hover:text-primary transition">
            <?= htmlspecialchars($_SESSION['user']['first_name'] . ' ' . $_SESSION['user']['last_name']) ?>
          </button>
          <div class="absolute hidden group-hover:block right-0 mt-2 bg-white dark:bg-zinc-800 rounded shadow-lg min-w-[180px]">
            <?php if ($_SESSION['user']['role'] === 'admin'): ?>
              <a href="<?= url('admin/dashboard') ?>" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-zinc-700">Tableau de bord Admin</a>
              <hr class="border-gray-200 dark:border-zinc-600">
            <?php endif; ?>
            <a href="<?= url('profile') ?>" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-zinc-700">Mon compte</a>
            <a href="<?= url('auth/logout') ?>" class="block px-4 py-2 hover:bg-gray-100 dark:hover:bg-zinc-700">Déconnexion</a>
          </div>
        </div>
      <?php else: ?>
        <a href="<?= url('auth/login') ?>" class="hover:text-primary transition">Connexion</a>
        <a href="<?= url('auth/register') ?>" class="hover:text-primary transition">Inscription</a>
      <?php endif; ?>

      <a href="<?= url('cart') ?>" class="relative hover:text-primary transition">
        <i class="bi bi-cart"></i>
        <span class="ml-1">Panier</span>
        <span class="absolute -top-2 -right-3 bg-secondary dark:bg-primary text-xs rounded-full px-2">0</span>
      </a>

      <!-- Dark Mode toggle -->
    <button id="toggle-dark-desktop" class="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-zinc-700 transition" title="Changer de thème">
    <svg id="sun-icon-desktop" class="h-5 w-5 hidden text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M12 3v1m0 16v1m8.66-8.66h-1M4.34 12H3m15.36 4.24l-.71-.71M6.34 6.34l-.71-.71m12.02 0l-.71.71M6.34 17.66l-.71.71M12 8a4 4 0 100 8 4 4 0 000-8z" />
    </svg>
    <svg id="moon-icon-desktop" class="h-5 w-5 hidden text-gray-800 dark:text-gray-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M21 12.79A9 9 0 1111.21 3a7 7 0 109.79 9.79z"/>
    </svg>
    </button>

    </nav>
  </div>

  <!-- Mobile nav -->
  <div id="mobile-menu" class="md:hidden hidden px-4 pb-4 space-y-3 font-body text-sm sm:text-base">
    <a href="<?= url() ?>" class="block hover:text-primary transition">Accueil</a>
    <a href="<?= url('products') ?>" class="block hover:text-primary transition">Produits</a>

    <?php if (isset($_SESSION['user'])): ?>
      <?php if ($_SESSION['user']['role'] === 'admin'): ?>
        <a href="<?= url('admin/dashboard') ?>" class="block hover:text-primary transition">Tableau de bord Admin</a>
      <?php endif; ?>
      <a href="<?= url('profile') ?>" class="block hover:text-primary transition">Mon compte</a>
      <a href="<?= url('auth/logout') ?>" class="block hover:text-primary transition">Déconnexion</a>
    <?php else: ?>
      <a href="<?= url('auth/login') ?>" class="block hover:text-primary transition">Connexion</a>
      <a href="<?= url('auth/register') ?>" class="block hover:text-primary transition">Inscription</a>
    <?php endif; ?>

    <a href="<?= url('cart') ?>" class="block relative hover:text-primary transition">
      <i class="bi bi-cart"></i>
      <span class="ml-1">Panier</span>
      <span class="absolute -top-2 -right-3 bg-secondary dark:bg-primary text-xs rounded-full px-2">0</span>
    </a>
  </div>
</header>

<script src="<?= url('assets/js/theme-toggle.js') ?>"></script>

<main class="max-w-7xl mx-auto px-4 py-6">
<?php
  $flash = $_SESSION['flash_message_rendered'] ?? null;
  unset($_SESSION['flash_message_rendered']);
  if ($flash):
?>
  <div class="mb-4 p-4 rounded-lg text-white bg-<?= $flash['type'] === 'success' ? 'green-500' : 'red-500' ?> shadow">
    <?= htmlspecialchars($flash['message']) ?>
  </div>
<?php endif; ?>

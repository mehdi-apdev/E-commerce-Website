<footer class="bg-white dark:bg-dark border-t border-gray-200 dark:border-zinc-700 mt-10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 md:grid-cols-3 gap-8 text-sm text-gray-700 dark:text-gray-300 font-body">
        
        <!-- Colonne 1 : Identité -->
        <div>
            <h2 class="text-xl font-heading text-primary mb-2"><?= SITE_NAME ?></h2>
            <p class="text-gray-600 dark:text-gray-400">Vêtements traditionnels algériens pour la diaspora.</p>
        </div>

        <!-- Colonne 2 : Navigation -->
        <div>
            <h3 class="text-base font-semibold mb-2 text-gray-800 dark:text-gray-200">Navigation</h3>
            <ul class="space-y-1">
                <li><a href="<?= url() ?>" class="hover:text-primary transition">Accueil</a></li>
                <li><a href="<?= url('products') ?>" class="hover:text-primary transition">Catalogue</a></li>
                <li><a href="<?= url('auth/login') ?>" class="hover:text-primary transition">Connexion</a></li>
                <li><a href="<?= url('auth/register') ?>" class="hover:text-primary transition">Inscription</a></li>
            </ul>
        </div>

        <!-- Colonne 3 : Légal / Contact -->
        <div>
            <h3 class="text-base font-semibold mb-2 text-gray-800 dark:text-gray-200">Informations</h3>
            <ul class="space-y-1">
                <li><a href="<?= url('contact') ?>" class="hover:text-primary transition">Contact</a></li>
                <li><a href="<?= url('legal') ?>" class="hover:text-primary transition">Mentions légales</a></li>
                <li><a href="<?= url('terms') ?>" class="hover:text-primary transition">Conditions générales</a></li>
            </ul>
        </div>
    </div>

    <div class="text-center text-xs text-gray-400 py-4 border-t border-gray-100 dark:border-zinc-700">
        &copy; <?= date('Y') ?> <?= SITE_NAME ?>. Tous droits réservés.
    </div>
</footer>
</body>
</html>
<?php
// app/views/products/index.php

$pageTitle = 'Nos produits - ' . SITE_NAME;
require APP_ROOT . '/views/partials/header.php';
?>

    <div class="container py-5">
        <h1 class="mb-4 text-center">Notre collection pour hommes</h1>

        <div class="mb-4 text-center">
            <form method="GET" class="row g-2 justify-content-center align-items-center">
                <div class="col-auto">
                    <label for="orderBy" class="form-label mb-0">Trier par :</label>
                </div>
                <div class="col-auto">
                    <select name="orderBy" id="orderBy" class="form-select">
                        <option value="p.created_at" <?= ($_GET['orderBy'] ?? '') === 'p.created_at' ? 'selected' : '' ?>>Date d'ajout</option>
                        <option value="p.name" <?= ($_GET['orderBy'] ?? '') === 'p.name' ? 'selected' : '' ?>>Nom</option>
                        <option value="p.price" <?= ($_GET['orderBy'] ?? '') === 'p.price' ? 'selected' : '' ?>>Prix</option>
                    </select>
                </div>

                <div class="col-auto">
                    <select name="direction" id="direction" class="form-select">
                        <option value="ASC" <?= ($_GET['direction'] ?? '') === 'ASC' ? 'selected' : '' ?>>Ascendant</option>
                        <option value="DESC" <?= ($_GET['direction'] ?? '') === 'DESC' ? 'selected' : '' ?>>Descendant</option>
                    </select>
                </div>

                <div class="col-auto">
                    <button type="submit" class="btn btn-outline-primary">Trier</button>
                </div>
            </form>
        </div>

    <?php if (!empty($products)): ?>
        <div class="row">
            <?php foreach ($products as $product): ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card h-100 shadow-sm">
                        <?php if (!empty($product['main_image'])): ?>
                            <?php $imagePath = UPLOADS_DIR . '/' . $product['product_id'] . '/' . $product['main_image']; ?>
                            <img src="<?= url($imagePath) ?>" class="card-img-top" alt="<?= htmlspecialchars($product['name']) ?>">
                        <?php else: ?>
                            <div class="bg-secondary text-white d-flex align-items-center justify-content-center" style="height: 200px;">
                                Pas d'image
                            </div>
                        <?php endif; ?>

                        <div class="card-body">
                            <h5 class="card-title"><?= htmlspecialchars($product['name']) ?></h5>
                            <p class="card-text"><?= htmlspecialchars($product['short_description']) ?></p>
                            <p class="card-text"><strong>Prix:</strong> <?= formatPrice($product['price']) ?></p>

                            <?php if (!empty($product['category_name'])): ?>
                                <p class="card-text"><strong>Catégorie:</strong> <?= htmlspecialchars($product['category_name']) ?></p>
                            <?php endif; ?>

                            <?php if (!empty($product['fabric_name'])): ?>
                                <p class="card-text"><strong>Tissu:</strong> <?= htmlspecialchars($product['fabric_name']) ?></p>
                            <?php endif; ?>

                            <?php if (!empty($product['region_name'])): ?>
                                <p class="card-text"><strong>Région culturelle:</strong> <?= htmlspecialchars($product['region_name']) ?></p>
                            <?php endif; ?>

                            <div class="d-grid">
                                <a href="<?= url('products/view/' . $product['product_id']) ?>" class="btn btn-primary">Voir détails</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        
        <!-- Pagination -->
        <?php if ($totalPages > 1): ?>
            <nav aria-label="Pagination des produits">
                <ul class="pagination justify-content-center">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= ($i === $currentPage) ? 'active' : '' ?>">
                            <a class="page-link" href="<?= url("products?page=$i") ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        <?php endif; ?>

    <?php else: ?>
        <div class="alert alert-warning text-center">Aucun produit disponible pour le moment.</div>
    <?php endif; ?>
</div>

<?php require APP_ROOT . '/views/partials/footer.php'; ?>

<?php
// app/views/users/account.php

$pageTitle = 'Mon compte - ' . SITE_NAME;

// Include header
require APP_ROOT . '/views/partials/header.php';
?>

<div class="container py-5">
    <h2 class="mb-4 text-center">Mon compte</h2>

    <div class="row justify-content-center">
        <div class="col-md-6">

            <div class="card shadow-sm">
                <div class="card-body">
                    <h5 class="card-title mb-3">Bonjour <?= htmlspecialchars($user['first_name'] ?? '') ?> <?= htmlspecialchars($user['last_name'] ?? '') ?> 👋</h5>

                    <p class="card-text"><strong>Email :</strong> <?= htmlspecialchars($user['email'] ?? '') ?></p>
                    <p class="card-text"><strong>Téléphone :</strong> <?= htmlspecialchars($user['phone'] ?? 'Non renseigné') ?></p>

                    <div class="mt-4">
                        <a href="<?= url('auth/logout') ?>" class="btn btn-danger">Se déconnecter</a>
                        <a href="<?= url('user/edit') ?>" class="btn btn-outline-primary mt-3">Modifier mes informations</a>
                        <!-- <a href="<?= url('user/edit') ?>" class="btn btn-outline-primary ms-2">Modifier mes infos</a> -->
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<?php
// Include footer
require APP_ROOT . '/views/partials/footer.php';

<?php
// app/views/users/edit.php

$pageTitle = 'Modifier mon profil - ' . SITE_NAME;
require APP_ROOT . '/views/partials/header.php';
$errors = $_SESSION['errors'] ?? [];
$form = $_SESSION['form_data'] ?? $user;
unset($_SESSION['errors'], $_SESSION['form_data']);
?>

<div class="container py-5">
    <h2 class="mb-4 text-center">Modifier mes informations</h2>

    <form action="<?= url('user/editPost') ?>" method="post" class="col-md-6 offset-md-3">
        <div class="mb-3">
            <label for="first_name" class="form-label">Prénom</label>
            <input type="text" name="first_name" id="first_name" class="form-control" value="<?= htmlspecialchars($form['first_name'] ?? '') ?>">
            <small class="text-danger"><?= $errors['first_name'] ?? '' ?></small>
        </div>

        <div class="mb-3">
            <label for="last_name" class="form-label">Nom</label>
            <input type="text" name="last_name" id="last_name" class="form-control" value="<?= htmlspecialchars($form['last_name'] ?? '') ?>">
            <small class="text-danger"><?= $errors['last_name'] ?? '' ?></small>
        </div>

        <div class="mb-3">
            <label for="phone" class="form-label">Téléphone</label>
            <input type="text" name="phone" id="phone" class="form-control" value="<?= htmlspecialchars($form['phone'] ?? '') ?>">
        </div>

        <div class="mb-3">
            <label for="password" class="form-label">Nouveau mot de passe</label>
            <input type="password" name="password" id="password" class="form-control">
            <small class="form-text text-muted">Laisse vide si tu ne veux pas le changer</small>
            <small class="text-danger"><?= $errors['password'] ?? '' ?></small>
        </div>

        <div class="mb-3">
            <label for="confirm_password" class="form-label">Confirmation du mot de passe</label>
            <input type="password" name="confirm_password" id="confirm_password" class="form-control">
            <small class="text-danger"><?= $errors['confirm_password'] ?? '' ?></small>
        </div>

        <div class="d-grid gap-2">
            <button type="submit" class="btn btn-primary">Enregistrer</button>
            <a href="<?= url('user/account') ?>" class="btn btn-secondary">Annuler</a>
        </div>
    </form>
</div>

<?php require APP_ROOT . '/views/partials/footer.php'; ?>

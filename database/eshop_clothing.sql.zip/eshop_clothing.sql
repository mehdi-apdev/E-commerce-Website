-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2025 at 10:37 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eshop_clothing`
--
CREATE DATABASE IF NOT EXISTS `eshop_clothing` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `eshop_clothing`;

-- --------------------------------------------------------

--
-- Table structure for table `accessories`
--

DROP TABLE IF EXISTS `accessories`;
CREATE TABLE IF NOT EXISTS `accessories` (
  `accessory_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `type` varchar(50) DEFAULT NULL,
  `placement` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`accessory_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bottoms`
--

DROP TABLE IF EXISTS `bottoms`;
CREATE TABLE IF NOT EXISTS `bottoms` (
  `bottom_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `style` varchar(50) DEFAULT NULL,
  `length` varchar(50) DEFAULT NULL,
  `waist_type` varchar(50) DEFAULT NULL,
  `has_pleats` tinyint(1) DEFAULT 0,
  `has_embroidery` tinyint(1) DEFAULT 0,
  `embroidery_description` text DEFAULT NULL,
  PRIMARY KEY (`bottom_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`category_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `name`, `description`, `parent_id`) VALUES
(1, 'Burnous', 'Cape traditionnelle en laine portée en hiver.', NULL),
(2, 'Gandoura', 'Tunique légère, souvent portée en été.', NULL),
(3, 'Jellaba', 'Vêtement mixte avec capuche, long et ample.', NULL),
(4, '3amama', 'Turban traditionnel.', NULL),
(5, 'Balgha', 'Chaussure traditionnelle en cuir.', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `colors`
--

DROP TABLE IF EXISTS `colors`;
CREATE TABLE IF NOT EXISTS `colors` (
  `color_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `hex_value` varchar(7) DEFAULT NULL,
  `is_traditional` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`color_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `colors`
--

INSERT INTO `colors` (`color_id`, `name`, `hex_value`, `is_traditional`) VALUES
(1, 'Blanc', '#FFFFFF', 1),
(2, 'Noir', '#000000', 1),
(3, 'Beige', '#F5F5DC', 1),
(4, 'Rouge', '#FF0000', 0),
(5, 'Bleu', '#0000FF', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cultural_content`
--

DROP TABLE IF EXISTS `cultural_content`;
CREATE TABLE IF NOT EXISTS `cultural_content` (
  `content_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `region_id` int(11) DEFAULT NULL,
  `related_product_id` int(11) DEFAULT NULL,
  `related_outfit_id` int(11) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`content_id`),
  KEY `region_id` (`region_id`),
  KEY `related_product_id` (`related_product_id`),
  KEY `related_outfit_id` (`related_outfit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cultural_regions`
--

DROP TABLE IF EXISTS `cultural_regions`;
CREATE TABLE IF NOT EXISTS `cultural_regions` (
  `region_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `country` varchar(100) DEFAULT 'Algeria',
  PRIMARY KEY (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cultural_regions`
--

INSERT INTO `cultural_regions` (`region_id`, `name`, `description`, `country`) VALUES
(1, 'Kabyle', 'Région montagneuse d’Algérie, connue pour ses vêtements en laine et broderies colorées.', 'Algeria'),
(2, 'Chaoui', 'Région berbère avec des vêtements au style distinctif.', 'Algeria'),
(3, 'Sahara', 'Influences sahariennes dans les vêtements amples et adaptés au désert.', 'Algeria');

-- --------------------------------------------------------

--
-- Table structure for table `discount_coupons`
--

DROP TABLE IF EXISTS `discount_coupons`;
CREATE TABLE IF NOT EXISTS `discount_coupons` (
  `coupon_id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `discount_type` enum('percentage','fixed') NOT NULL,
  `discount_value` decimal(10,2) NOT NULL,
  `min_purchase` decimal(10,2) DEFAULT 0.00,
  `start_date` datetime NOT NULL,
  `end_date` datetime NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `usage_limit` int(11) DEFAULT NULL,
  `usage_count` int(11) DEFAULT 0,
  PRIMARY KEY (`coupon_id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fabrics`
--

DROP TABLE IF EXISTS `fabrics`;
CREATE TABLE IF NOT EXISTS `fabrics` (
  `fabric_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `is_traditional` tinyint(1) DEFAULT 0,
  `origin` varchar(100) DEFAULT NULL,
  `manufacturing_technique` text DEFAULT NULL,
  PRIMARY KEY (`fabric_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `fabrics`
--

INSERT INTO `fabrics` (`fabric_id`, `name`, `description`, `is_traditional`, `origin`, `manufacturing_technique`) VALUES
(1, 'Laine', 'Chaud et isolant, idéal pour l’hiver.', 1, 'Kabylie', 'Tissé à la main'),
(2, 'Coton', 'Léger et respirant.', 0, 'Algérie', 'Fait machine'),
(3, 'Soie', 'Luxueux et fluide.', 0, 'Importé', 'Tissage raffiné');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_logs`
--

DROP TABLE IF EXISTS `inventory_logs`;
CREATE TABLE IF NOT EXISTS `inventory_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `quantity_change` int(11) NOT NULL,
  `reason` enum('purchase','sale','return','damage','adjustment') NOT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `logged_at` datetime DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`log_id`),
  KEY `product_id` (`product_id`),
  KEY `size_id` (`size_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `address_id` int(11) NOT NULL,
  `status` enum('pending','confirmed','processing','shipped','delivered','cancelled') DEFAULT 'pending',
  `total_amount` decimal(10,2) NOT NULL,
  `shipping_fee` decimal(10,2) DEFAULT 0.00,
  `tax_amount` decimal(10,2) DEFAULT 0.00,
  `discount_amount` decimal(10,2) DEFAULT 0.00,
  `tracking_number` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`order_id`),
  KEY `user_id` (`user_id`),
  KEY `address_id` (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `address_id`, `status`, `total_amount`, `shipping_fee`, `tax_amount`, `discount_amount`, `tracking_number`, `notes`, `created_at`, `updated_at`) VALUES
(1, 4, 8, 'pending', 13.00, 0.00, 0.00, 0.00, NULL, NULL, '2025-05-03 13:34:56', NULL),
(2, 4, 9, 'pending', 253.99, 0.00, 0.00, 0.00, NULL, NULL, '2025-05-03 13:39:16', NULL),
(3, 4, 10, 'pending', 253.99, 0.00, 0.00, 0.00, NULL, NULL, '2025-05-07 19:17:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
CREATE TABLE IF NOT EXISTS `order_items` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `outfit_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `customization_notes` text DEFAULT NULL,
  PRIMARY KEY (`item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `outfit_id` (`outfit_id`),
  KEY `size_id` (`size_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`item_id`, `order_id`, `product_id`, `outfit_id`, `size_id`, `quantity`, `unit_price`, `customization_notes`) VALUES
(1, 1, 7, NULL, NULL, 1, 13.00, NULL),
(2, 2, 8, NULL, NULL, 1, 119.99, NULL),
(3, 2, 7, NULL, NULL, 1, 13.00, NULL),
(4, 2, 1, NULL, NULL, 1, 121.00, NULL),
(5, 3, 8, NULL, NULL, 1, 119.99, NULL),
(6, 3, 1, NULL, NULL, 1, 121.00, NULL),
(7, 3, 7, NULL, NULL, 1, 13.00, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `outfits`
--

DROP TABLE IF EXISTS `outfits`;
CREATE TABLE IF NOT EXISTS `outfits` (
  `outfit_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `discount_percentage` decimal(5,2) DEFAULT 0.00,
  `cultural_region_id` int(11) DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`outfit_id`),
  KEY `cultural_region_id` (`cultural_region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `outfit_products`
--

DROP TABLE IF EXISTS `outfit_products`;
CREATE TABLE IF NOT EXISTS `outfit_products` (
  `outfit_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`outfit_id`,`product_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE IF NOT EXISTS `payments` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `payment_method` enum('credit_card','paypal','bank_transfer','other') NOT NULL,
  `payment_status` enum('pending','completed','failed','refunded') DEFAULT 'pending',
  `amount` decimal(10,2) NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `payment_date` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`payment_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `category_id` int(11) NOT NULL,
  `color_id` int(11) DEFAULT NULL,
  `fabric_id` int(11) DEFAULT NULL,
  `cultural_region_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `creation_time_hours` int(11) DEFAULT NULL,
  `historical_information` text DEFAULT NULL,
  `is_featured` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  `stock` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`product_id`),
  KEY `category_id` (`category_id`),
  KEY `color_id` (`color_id`),
  KEY `fabric_id` (`fabric_id`),
  KEY `cultural_region_id` (`cultural_region_id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `description`, `short_description`, `price`, `category_id`, `color_id`, `fabric_id`, `cultural_region_id`, `supplier_id`, `creation_time_hours`, `historical_information`, `is_featured`, `created_at`, `updated_at`, `stock`) VALUES
(1, 'Burnous Kabyle Blanc', 'Cape kabyle en laine blanche, idéale pour l’hiver.', 'Burnous traditionnel en laine.', 121.00, 1, 1, 2, 2, 1, NULL, NULL, 0, '2025-04-03 16:19:23', '2025-05-07 19:17:55', 4),
(2, 'Gandoura Coton Blanche', 'Tunique ample en coton blanche, parfaite pour l’été.', 'Gandoura élégante.', 60.00, 2, 1, 2, 2, 2, NULL, NULL, 0, '2025-04-03 16:19:23', '2025-05-03 12:51:33', 14),
(7, 'amama', '', '', 13.00, 4, 1, NULL, 2, NULL, NULL, NULL, 0, '2025-04-06 15:33:30', '2025-05-07 19:17:55', 4),
(8, 'Burnous rouge', '', '', 119.99, 1, 4, 1, NULL, NULL, NULL, NULL, 0, '2025-04-06 20:39:04', '2025-05-07 21:17:08', 0),
(12, 'test 213', '', '', 0.02, 3, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2025-05-07 22:25:53', NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

DROP TABLE IF EXISTS `product_images`;
CREATE TABLE IF NOT EXISTS `product_images` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `outfit_id` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `is_main` tinyint(1) DEFAULT 0,
  `image_type` enum('product','detail','lifestyle','cultural') DEFAULT 'product',
  `caption` text DEFAULT NULL,
  PRIMARY KEY (`image_id`),
  KEY `product_id` (`product_id`),
  KEY `outfit_id` (`outfit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`image_id`, `product_id`, `outfit_id`, `filename`, `is_main`, `image_type`, `caption`) VALUES
(1, 1, NULL, 'burnous.jpg\r\n', 1, 'product', NULL),
(2, 2, NULL, 'gandoura.jpg', 1, 'product', NULL),
(3, 7, NULL, 'img_1743946410.jpg', 1, 'product', NULL),
(4, 8, NULL, 'img_1743964744.jpg', 0, 'product', NULL),
(5, 8, NULL, 'img_1743964867.jpg', 1, 'product', NULL),
(7, 12, NULL, 'img_1746649553.png', 1, 'product', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shipping_addresses`
--

DROP TABLE IF EXISTS `shipping_addresses`;
CREATE TABLE IF NOT EXISTS `shipping_addresses` (
  `address_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `recipient_name` varchar(200) NOT NULL,
  `street` varchar(255) NOT NULL,
  `number` int(5) NOT NULL,
  `postal_code` varchar(10) NOT NULL,
  `city` varchar(100) NOT NULL,
  `region` varchar(100) DEFAULT NULL,
  `country` varchar(100) NOT NULL DEFAULT 'Belgium',
  `is_default` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`address_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shipping_addresses`
--

INSERT INTO `shipping_addresses` (`address_id`, `user_id`, `recipient_name`, `street`, `number`, `postal_code`, `city`, `region`, `country`, `is_default`) VALUES
(1, 1, 'Karim Benali', 'Rue de l’Atlas 12', 0, '1000', 'Bruxelles', 'Bruxelles-Capitale', 'Belgium', 1),
(2, 2, 'Yacine Amari', 'Rue des Aurès 8', 0, '5000', 'Namur', 'Wallonie', 'Belgium', 1),
(8, 4, 'Mehdi El Mestari', 'Chaussée de Binche', 169, '7000', 'Mons', '', 'Belgium', 0),
(9, 4, 'test 2', 'ZZ', 12, '233', 'DD', '', 'Belgium', 0),
(10, 4, 'Mehdi El Mestari', 'Chaussée de Binche', 169, '7000', 'Mons', '', 'Belgium', 0);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

DROP TABLE IF EXISTS `shopping_cart`;
CREATE TABLE IF NOT EXISTS `shopping_cart` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `size_id` int(11) DEFAULT NULL,
  `outfit_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT 1,
  `customization_notes` text DEFAULT NULL,
  `added_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`cart_id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  KEY `size_id` (`size_id`),
  KEY `outfit_id` (`outfit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `shopping_cart`
--

INSERT INTO `shopping_cart` (`cart_id`, `user_id`, `product_id`, `size_id`, `outfit_id`, `quantity`, `customization_notes`, `added_at`) VALUES
(1, 1, 1, 1, NULL, 1, NULL, '2025-04-03 16:19:23');

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

DROP TABLE IF EXISTS `sizes`;
CREATE TABLE IF NOT EXISTS `sizes` (
  `size_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `size_label` varchar(10) NOT NULL,
  `size_description` varchar(100) DEFAULT NULL,
  `stock_qty` int(10) UNSIGNED NOT NULL,
  `reorder_level` int(10) UNSIGNED DEFAULT 5,
  PRIMARY KEY (`size_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`size_id`, `product_id`, `size_label`, `size_description`, `stock_qty`, `reorder_level`) VALUES
(1, 1, 'M', 'Taille moyenne', 5, 5),
(2, 1, 'L', 'Taille large', 3, 5),
(3, 2, 'S', 'Petite taille', 4, 5),
(4, 7, 'M', 'Taille moyenne', 2, 5),
(6, 8, 'M', NULL, 5, 5),
(7, 8, 'S', NULL, 2, 5),
(8, 12, 'XL', NULL, 2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
CREATE TABLE IF NOT EXISTS `suppliers` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `region_id` int(11) DEFAULT NULL,
  `is_artisan` tinyint(1) DEFAULT 0,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`supplier_id`),
  KEY `region_id` (`region_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`supplier_id`, `name`, `contact_person`, `email`, `phone`, `address`, `region_id`, `is_artisan`, `notes`) VALUES
(1, 'Artisanat Kabyle', 'Amar B.', 'amar@kabyle.com', '0485123456', 'Tizi-Ouzou, Kabylie', 1, 1, NULL),
(2, 'Chaoui Création', 'Lyes C.', 'lyes@chaoui.com', '0455123456', 'Batna, Aurès', 2, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tops`
--

DROP TABLE IF EXISTS `tops`;
CREATE TABLE IF NOT EXISTS `tops` (
  `top_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `sleeve_type` varchar(50) DEFAULT NULL,
  `neck_style` varchar(50) DEFAULT NULL,
  `length` varchar(50) DEFAULT NULL,
  `has_embroidery` tinyint(1) DEFAULT 0,
  `embroidery_description` text DEFAULT NULL,
  PRIMARY KEY (`top_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `last_name` varchar(100) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('customer','admin','staff') DEFAULT 'customer',
  `phone` varchar(20) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `last_login` datetime DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `remember_token` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `last_name`, `first_name`, `email`, `password`, `role`, `phone`, `created_at`, `last_login`, `is_active`, `remember_token`) VALUES
(1, 'Benali', 'Karim', 'karim@mail.com', 'hashed_pwd_123', 'customer', '0471000000', '2025-04-03 16:19:23', NULL, 1, NULL),
(2, 'Amari', 'Yacine', 'yacine@mail.com', 'hashed_pwd_456', 'customer', '0482000000', '2025-04-03 16:19:23', NULL, 1, NULL),
(3, '1', 'testAdmin', 'test1@hotmail.com', '$2y$12$RaLtcTtHX6BdK85vCNEAHeyzwCdgFVocR.GHnrTArwxlkCUEYQ6lS', 'admin', '', '2025-04-05 16:30:28', '2025-05-07 19:20:42', 1, '68988156b79a508fa21c1f613e0c3398843e322e21549ec91bc44ee1e6f31d41'),
(4, '2', 'test', 'test2@hotmail.com', '$2y$12$jN4xjrHy8waRM4HqJ314neadjgvj9cCrOYU8OLoJzZCzmOgQmB6n6', 'customer', '', '2025-04-05 22:59:44', '2025-05-03 13:34:46', 1, 'bc77be39b23367300aa406c6c5ebdbe5a5e728988adc807f522bb078bb2e0f16'),
(5, '3', 'test', 'test3@hotmail.com', '$2y$12$XbeJUX9xz99yXz7Ly6Ypbe1jB7DWbW7OSAH6xBS/YDNT1LlhXcRKW', 'customer', '', '2025-04-05 23:12:00', NULL, 1, NULL),
(6, '4', 'test', 'test4@hotmail.com', '$2y$12$DlI89OGXOvblAmW2GKmqq.TnQvkmwMbf8ndukXpw.gMaANdKWgrFy', 'customer', '', '2025-04-15 18:57:56', '2025-04-23 20:47:26', 1, '3ffa0013c574d5d3ba270cd8199cffd3ce7041a277e74fcd7cd8ae91056885ea'),
(7, '5', 'test', 'test5@hotmail.com', '$2y$12$BGZwux4cq7fo5VMKPcZ.FOHAzyuGaMP88vKHcnysAhcN1zm1hflOK', 'customer', '', '2025-04-15 19:13:37', NULL, 1, NULL),
(9, '6', 'test', 'test6@hotmail.com', '$2y$12$s9WMo30qdXQ8EGn7XMJcluFO0sIcG0SCkxW3T7lEhGy9yu0jMFI9q', 'customer', '', '2025-04-15 22:04:03', NULL, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_reviews`
--

DROP TABLE IF EXISTS `user_reviews`;
CREATE TABLE IF NOT EXISTS `user_reviews` (
  `review_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `outfit_id` int(11) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL CHECK (`rating` between 1 and 5),
  `title` varchar(255) DEFAULT NULL,
  `comment` text DEFAULT NULL,
  `has_photo` tinyint(1) DEFAULT 0,
  `verified_purchase` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`review_id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  KEY `outfit_id` (`outfit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

DROP TABLE IF EXISTS `wishlists`;
CREATE TABLE IF NOT EXISTS `wishlists` (
  `wishlist_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `outfit_id` int(11) DEFAULT NULL,
  `added_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`wishlist_id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`),
  KEY `outfit_id` (`outfit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `wishlists`
--

INSERT INTO `wishlists` (`wishlist_id`, `user_id`, `product_id`, `outfit_id`, `added_at`) VALUES
(1, 2, 2, NULL, '2025-04-03 16:19:23');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `accessories`
--
ALTER TABLE `accessories`
  ADD CONSTRAINT `accessories_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `bottoms`
--
ALTER TABLE `bottoms`
  ADD CONSTRAINT `bottoms_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`category_id`);

--
-- Constraints for table `cultural_content`
--
ALTER TABLE `cultural_content`
  ADD CONSTRAINT `cultural_content_ibfk_1` FOREIGN KEY (`region_id`) REFERENCES `cultural_regions` (`region_id`),
  ADD CONSTRAINT `cultural_content_ibfk_2` FOREIGN KEY (`related_product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `cultural_content_ibfk_3` FOREIGN KEY (`related_outfit_id`) REFERENCES `outfits` (`outfit_id`);

--
-- Constraints for table `inventory_logs`
--
ALTER TABLE `inventory_logs`
  ADD CONSTRAINT `inventory_logs_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `inventory_logs_ibfk_2` FOREIGN KEY (`size_id`) REFERENCES `sizes` (`size_id`),
  ADD CONSTRAINT `inventory_logs_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`address_id`) REFERENCES `shipping_addresses` (`address_id`);

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `order_items_ibfk_3` FOREIGN KEY (`outfit_id`) REFERENCES `outfits` (`outfit_id`),
  ADD CONSTRAINT `order_items_ibfk_4` FOREIGN KEY (`size_id`) REFERENCES `sizes` (`size_id`);

--
-- Constraints for table `outfits`
--
ALTER TABLE `outfits`
  ADD CONSTRAINT `outfits_ibfk_1` FOREIGN KEY (`cultural_region_id`) REFERENCES `cultural_regions` (`region_id`);

--
-- Constraints for table `outfit_products`
--
ALTER TABLE `outfit_products`
  ADD CONSTRAINT `outfit_products_ibfk_1` FOREIGN KEY (`outfit_id`) REFERENCES `outfits` (`outfit_id`),
  ADD CONSTRAINT `outfit_products_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`category_id`),
  ADD CONSTRAINT `products_ibfk_2` FOREIGN KEY (`color_id`) REFERENCES `colors` (`color_id`),
  ADD CONSTRAINT `products_ibfk_3` FOREIGN KEY (`fabric_id`) REFERENCES `fabrics` (`fabric_id`),
  ADD CONSTRAINT `products_ibfk_4` FOREIGN KEY (`cultural_region_id`) REFERENCES `cultural_regions` (`region_id`),
  ADD CONSTRAINT `products_ibfk_5` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`supplier_id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `product_images_ibfk_2` FOREIGN KEY (`outfit_id`) REFERENCES `outfits` (`outfit_id`);

--
-- Constraints for table `shipping_addresses`
--
ALTER TABLE `shipping_addresses`
  ADD CONSTRAINT `shipping_addresses_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD CONSTRAINT `shopping_cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `shopping_cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `shopping_cart_ibfk_3` FOREIGN KEY (`size_id`) REFERENCES `sizes` (`size_id`),
  ADD CONSTRAINT `shopping_cart_ibfk_4` FOREIGN KEY (`outfit_id`) REFERENCES `outfits` (`outfit_id`);

--
-- Constraints for table `sizes`
--
ALTER TABLE `sizes`
  ADD CONSTRAINT `sizes_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD CONSTRAINT `suppliers_ibfk_1` FOREIGN KEY (`region_id`) REFERENCES `cultural_regions` (`region_id`);

--
-- Constraints for table `tops`
--
ALTER TABLE `tops`
  ADD CONSTRAINT `tops_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `user_reviews`
--
ALTER TABLE `user_reviews`
  ADD CONSTRAINT `user_reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `user_reviews_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `user_reviews_ibfk_3` FOREIGN KEY (`outfit_id`) REFERENCES `outfits` (`outfit_id`);

--
-- Constraints for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `wishlists_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `wishlists_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  ADD CONSTRAINT `wishlists_ibfk_3` FOREIGN KEY (`outfit_id`) REFERENCES `outfits` (`outfit_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
